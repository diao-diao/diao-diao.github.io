package com.ceit.controller;

import com.ceit.pojo.User;
import com.ceit.utils.JsonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class UserController {
    @RequestMapping(value = "/time3")
    @ResponseBody
    public String json6() throws JsonProcessingException {

        Date date = new Date();
        return JsonUtils.getJson(date);

    }

}