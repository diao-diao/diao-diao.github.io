<template>
  <div>
    <h1>你的页面走丢了</h1>
  </div>
</template>

<script>
  export default {
    name: "NotFound"
  }
</script>

<style scoped>

</style>
