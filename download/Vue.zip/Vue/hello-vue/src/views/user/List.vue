<template>
  <h1>用户列表页</h1>
</template>

<script>
  export default {
    name: "UserList"
  }
</script>

<style scoped>

</style>
