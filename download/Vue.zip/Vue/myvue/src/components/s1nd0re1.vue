<template>
  <h1>s1nd0re1</h1>
</template>

<script>
  export default {
    name: "s1nd0re1"
  }
</script>

<style scoped>

</style>
