//暴露一个方法
exports.sayHi = function () {
    document.write("<h1>51nd0re1 ES6</h1>")
};