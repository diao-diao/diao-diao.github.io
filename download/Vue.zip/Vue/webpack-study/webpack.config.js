module.exports = {
    entry:'./modules/main.js',
    output:{
        filename:"./js/bundle.js"
    }
};