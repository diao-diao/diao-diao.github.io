package com.ceit.springboot_jsp_shiro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJspShiroApplicationTests {

    @Test
    void contextLoads() {
    }

}
